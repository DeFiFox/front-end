import styled from 'styled-components'

const InfoRow = styled.div`
  align-items: center;
  display: flex;
  justify-content: space-between;
`

export default InfoRow
